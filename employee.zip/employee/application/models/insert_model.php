<?php 
class insert_model extends CI_Model{
	public function insert_employee_details($insertData){
		// echo 1;exit;
		$this->db->insert('employee_details',$insertData);
		$insert_id = $this->db->insert_id();
		return $insert_id;
	}
	public function get_employee_data(){
		$this->db->select('*');
		$this->db->from('employee_details');
		$query = $this->db->get();
		if($query->num_rows() > 0){
			$result = $query->result();
			return $result;
		}

	}
	
}
?>