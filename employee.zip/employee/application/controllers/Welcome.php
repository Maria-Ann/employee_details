<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Welcome extends CI_Controller {
	public function __construct()
	{
		parent::__construct();
			$this->load->model('insert_model');
			$this->load->library('csvimport');
	}
	public function index()
	{
		$data['employee_details'] = $this->insert_model->get_employee_data();
		$this->load->view('import_employee_details',$data);
	}
	public function employee_details(){
		if(isset($_POST['importSubmit'])){
		    $file_data = $this->csvimport->get_array($_FILES["file"]["tmp_name"]);
			foreach($file_data as $row){
			 	$insertData  = array( 
		                	'employee_code' => $row['employee_code'],
		                	'employee_name' => $row['employee_name'],
		                	'department' => $row['department'],
		                	'date_of_birth' => $row['date_of_birth'],
		                	'date_of_joining' => $row['date_of_joining'],
		                	 );
				$insert_id = $this->insert_model->insert_employee_details($insertData);
			}
		}
	redirect('Welcome/index');		
	}
	
}
