<!-- Bootstrap library -->
 <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
 <link rel="stylesheet" href="<?php echo base_url()?>assets/css/style.css">
 <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
 <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
 <div class="container">
  	<h2>Employee Details</h2>
	<div class="row">
	    <div class="col-md-12" id="importFrm" >
	        <form action="<?php echo base_url()?>welcome/employee_details" method="post" enctype="multipart/form-data">
	            <input type="file" name="file" />
	            <input type="submit" class="btn btn-success" name="importSubmit" value="IMPORT">
	        </form>
	    </div>

	    <!-- Data list table --> 
	    <table class="table table-striped table-bordered">
	        <thead class="thead-dark">
	            <tr>
	                <th>#Sl.No</th>
	                <th>Employee Code</th>
	                <th>Employee Name</th>
	                <th>Department</th>
	                <th>Age</th>
	                <th>Experience</th>
	            </tr>
	        </thead>
	        <tbody>
	        <?php
	        if(!empty($employee_details)){
	            for($i=0;$i<count($employee_details);$i++){
	        ?>
	            <tr>
	            	<td><?php echo $i+1 ?></td>
	                <td><?php echo $employee_details[$i]->employee_code; ?></td>
	                <td><?php echo $employee_details[$i]->employee_name; ?></td>
	                <td><?php echo $employee_details[$i]->department; ?></td>
	                <?php   
	                	$birthDate =  $employee_details[$i]->date_of_birth;
						$birthDate = explode("-", $birthDate);
						$age = date("Y") - $birthDate[2];
	                ?>
	                <td><?php echo $age; ?></td>
	                <?php   
	                	$date_of_joining =  $employee_details[$i]->date_of_joining;
						$date_of_joining = explode("-", $date_of_joining);
						$experience = date("Y") - $date_of_joining[2];
	                ?>
	                <td><?php echo $experience; ?></td>
	            </tr>
	        <?php } }else{ ?>
	            <tr><td colspan="5">No member(s) found...</td></tr>
	        <?php } ?>
	        </tbody>
	    </table>
	</div>
</div>

